<?php
$__lang['de_DE'] = array(
	'folder_contents' => 'Dies war mal "Ordner enthält". Wurde von sample Extension geändert.',
);

$__lang['es_ES'] = array(
	'folder_contents' => 'Esta vista "contiene carpetas". Cambiado de extensión de no conformidades.',
	'add_process' => 'Añadir proceso'
);

?>
